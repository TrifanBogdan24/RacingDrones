#pragma once


#include "components/simple_scene.h"
#include "RectangularParallelipiped.h"
#include "lab_m1/DroneGame/Camera.h"

#include "lab_m1/DroneGame/Obstacles/Tree.h"
#include "lab_m1/DroneGame/Obstacles/Dome.h"

class Drone {
    public:
        glm::vec3 position;
        RectangularParallelipiped arm1;
        RectangularParallelipiped arm2;
        RectangularParallelipiped leg1;
        RectangularParallelipiped leg2;
        RectangularParallelipiped leg3;
        RectangularParallelipiped leg4;
        RectangularParallelipiped propeller1;
        RectangularParallelipiped propeller2;
        RectangularParallelipiped propeller3;
        RectangularParallelipiped propeller4;

    public:
        float angleOX;  // axa stanga-dreapta
        float angleOY;  // axa sus-jos
        float angleOZ;  // axa inainte-inapoi

        float anglePropellerOZ;
        gamecamera::Camera* camera;

        int mapLength;

        vector<Tree>* trees;
        vector<Dome>* domes;

    private:
        float flightSpeed;
        float rotationSpeed;
        float altitudeAscendSpeed;
        float altitudeDescendSpeed;

    public:
        Drone() = default;
        
    public:
        void Init(
            glm::vec3 positionValue, gamecamera::Camera* cameraPtrValue,
            float mapLenghtValue, vector<Tree>* treesValue, vector<Dome>* domesValue
        );


    public:
        void Update(float deltaTime);
        void MoveLeft(float deltaTime);
        void MoveRight(float deltaTime);
        void MoveForward(float deltaTime);
        void MoveBackward(float deltaTime);
        void AscendAltitude(float deltaTime);
        void DescendAltitude(float deltaTime);
        void RotateLeft(float deltaTime);
        void RotateRight(float deltaTime);
        void UpdatePropellers(float deltaTime);

        void AnulateFlightSpeed();
        void AnulateAltitudeAscendSpeed();
        void AnulateAltitudeDescendSpeed();


        glm::vec3 GetForwardDirection() const;
        glm::vec3 GetPosition() const;

};

