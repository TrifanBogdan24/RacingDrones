#pragma once

#include "lab_m1/DroneGame/Transform3D.h"

#include <vector>
#include <iostream>

using namespace std;

class Tree
{
public:
	static class Trunk {
	public:
		float height;
		float radius;
		Mesh* mesh;
		glm::mat4 modelMatrix;

	public:
		Trunk() = default;
		Trunk(float heightValue, float radiusValue, Mesh* meshValue)
		{
			this->height = heightValue;
			this->radius = radiusValue;
			this->mesh = meshValue;
		}

	};


	static class Cone {
	public:
		float height;
		float radius;
		Mesh* mesh;
		glm::mat4 modelMatrix;

	public:
		Cone() = default;
		Cone(float heightValue, float radiusValue, Mesh* meshValue)
		{
			this->height = heightValue;
			this->radius = radiusValue;
			this->mesh = meshValue;
		}
	};

public:
	glm::vec3 position;
	Trunk trunk;
	vector<Cone> cones;


public:
	Tree() = default;

	Tree(glm::vec3 positionValue, Trunk& trunkValue, vector<Cone>& conesValue)
	{
		this->position = positionValue;
		this->trunk = trunkValue;
		this->cones = conesValue;

		this->trunk.modelMatrix =
			Transform3D::Translate(position.x, position.y, position.z)
			* Transform3D::Scale(trunk.radius, trunk.height, trunk.radius)
			* Transform3D::RotateOY(glm::radians(0.0f));

		float heightOffset = position.y + trunk.height * 2.f;

		for (Cone& cone : this->cones) {
			cone.modelMatrix =
				Transform3D::Translate(position.x, heightOffset, position.z)
				* Transform3D::Scale(cone.radius, cone.height, cone.radius);

			heightOffset += 0.4f * cone.height;
		}
	}
};