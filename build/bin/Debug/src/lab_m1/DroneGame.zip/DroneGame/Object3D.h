#pragma once

#include <string>

#include "core/gpu/mesh.h"
#include "utils/glm_utils.h"



namespace Object3D
{
	Mesh* CreateCylinder(const std::string& name)
	{
        // Define cylinder parameters
        const int numSegments = 36;
        const float radius = 0.5f;
        const float height = 2.0f;
        std::vector<VertexFormat> vertices;
        std::vector<unsigned int> indices;

        // Generate the top and bottom circle vertices
        for (int i = 0; i < numSegments; ++i) {
            float angle = i * 2.0f * glm::pi<float>() / numSegments;
            float x = radius * cos(angle);
            float z = radius * sin(angle);

            vertices.push_back(VertexFormat(glm::vec3(x, 0.0f, z), glm::vec3(1, 1, 1)));
            vertices.push_back(VertexFormat(glm::vec3(x, height, z), glm::vec3(1, 1, 1)));
        }

        // Generate indices for the side faces
        for (int i = 0; i < numSegments; ++i) {
            int next = (i + 1) % numSegments;

            // Two triangles for each quad
            indices.push_back(2 * i);         // Bottom vertex
            indices.push_back(2 * i + 1);     // Top vertex
            indices.push_back(2 * next);      // Next bottom vertex

            indices.push_back(2 * next);      // Next bottom vertex
            indices.push_back(2 * i + 1);     // Top vertex
            indices.push_back(2 * next + 1);  // Next top vertex
        }

        // Generate indices for the top and bottom circles
        for (int i = 1; i < numSegments - 1; ++i) {
            // Bottom circle
            indices.push_back(0);
            indices.push_back(2 * i);
            indices.push_back(2 * (i + 1));

            // Top circle
            indices.push_back(1);
            indices.push_back(2 * i + 1);
            indices.push_back(2 * (i + 1) + 1);
        }

        Mesh* cylinder = new Mesh(name);
        cylinder->InitFromData(vertices, indices);
        return cylinder;
	}


    Mesh* CreateCone(const std::string& name)
    {
        // Define cone parameters
        const int numSegments = 36;
        const float radius = 0.5f;
        const float height = 2.0f;
        std::vector<VertexFormat> vertices;
        std::vector<unsigned int> indices;

        // Add the apex of the cone (top point)
        vertices.push_back(VertexFormat(glm::vec3(0.0f, height, 0.0f), glm::vec3(1, 1, 1)));  // Apex vertex

        // Generate the bottom circle vertices (base of the cone)
        for (int i = 0; i < numSegments; ++i) {
            float angle = i * 2.0f * glm::pi<float>() / numSegments;
            float x = radius * cos(angle);
            float z = radius * sin(angle);
            vertices.push_back(VertexFormat(glm::vec3(x, 0.0f, z), glm::vec3(1, 1, 1)));  // Base vertices
        }

        // Generate indices for the side faces (cone's surface)
        for (int i = 1; i < numSegments; ++i) {
            int next = i + 1;
            if (i == numSegments - 1) {
                next = 1;  // Wrap around for the last segment
            }

            // Side triangle (for each segment)
            indices.push_back(0);          // Apex vertex
            indices.push_back(i);          // Current base vertex
            indices.push_back(next);       // Next base vertex
        }

        // Create a mesh for the cone
        Mesh* cone = new Mesh(name);
        cone->InitFromData(vertices, indices);
        return cone;
    }
}