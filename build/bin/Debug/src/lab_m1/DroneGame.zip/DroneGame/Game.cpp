#include "Game.h"
#include "Drone.h"
#include "Transform3D.h"
#include "lab_m1/DroneGame/Camera.h"
#include "Object3D.h"

#include "lab_m1/DroneGame/Obstacles/Tree.h"

#include <vector>
#include <string>
#include <iostream>

// For Randoms
#include <cstdlib>
#include <ctime>



// RGB(117, 117, 117)
#define COLOR_GREY glm::vec3(117.f/255.f, 117.f/255.f, 117.f/255.f)

// RGB(0, 0, 0)
#define COLOR_BLACK glm::vec3(0.f/255.f, 0.f/255.f, 0.f/255.f)

#define COLOR_GREEN_TREE_CONE glm::vec3(6.f, 56.f, 7.f)

// RGB(54, 24, 2)
#define COLOR_BROWN_TREE_TRUNK glm::vec3(54.f/255.f, 24.f/255.f, 2.f/255.f)

#define MAP_LENGTH 50.f

using namespace std;
using namespace m1;



/*
 *  To find out more about `FrameStart`, `Update`, `FrameEnd`
 *  and the order in which they are called, see `world.cpp`.
 */


Game::Game()
{
}


Game::~Game()
{
}


void Game::Init()
{
    std::srand(static_cast<unsigned>(std::time(0)));

    camera = new gamecamera::Camera();
    camera->Set(glm::vec3(0.7f, 0.7f, 0.6f), glm::vec3(0.f, 101.f, 0.f), glm::vec3(0.f, 1.f, 0.f));


    this->InitDrone();
    this->InitDomes();    // Place the DOMES first !!!
    this->InitForest();

    // TODO: repara shader-ul (eventually in viitor)
    Shader* shader = new Shader("VertexColor");

    shader->AddShader(PATH_JOIN(window->props.selfDir, SOURCE_PATH::M1, "DroneGame", "shaders", "VertexShader.glsl"), GL_VERTEX_SHADER);
    shader->AddShader(PATH_JOIN(window->props.selfDir, SOURCE_PATH::M1, "DroneGame", "shaders", "FragmentShader.glsl"), GL_FRAGMENT_SHADER);
    shader->CreateAndLink();
    shaders[shader->GetName()] = shader;
    if (shader->program == 0) {
        std::cerr << "Shader 'VertexColor' has not been compiled or linked correctly!" << std::endl;
        return;
    }

    polygonMode = GL_FILL;

    Mesh* terrainMesh = new Mesh("Terrain");
    terrainMesh->LoadMesh(PATH_JOIN(window->props.selfDir, RESOURCE_PATH::MODELS, "primitives"), "plane50.obj");
    meshes["Terrain"] = terrainMesh;

    Mesh* mesh = new Mesh("box");
    mesh->LoadMesh(PATH_JOIN(window->props.selfDir, RESOURCE_PATH::MODELS, "primitives"), "box.obj");
    meshes[mesh->GetMeshID()] = mesh;





    Shader *shaderDrone = shaders["Simple"];
    glm::vec3 position(0.f, 1.f, 0.f);


    this->drone = Drone();
    drone.Init(position, camera, MAP_LENGTH, &trees, &domes);


    // Initialize tx, ty and tz (the translation steps)
    translateX = 0;
    translateY = 0;
    translateZ = 0;

    // Initialize sx, sy and sz (the scale factors)
    scaleX = 1;
    scaleY = 1;
    scaleZ = 1;

    // Initialize angular steps
    angularStepOX = 0;
    angularStepOY = 0;
    angularStepOZ = 0;

    // Sets the resolution of the small viewport
    glm::ivec2 resolution = window->GetResolution();
    miniViewportArea = ViewportArea(50, 50, resolution.x / 5.f, resolution.y / 5.f);



    terrainModelMatrix =
        glm::mat4(1.0f)
        * Transform3D::Translate(-MAP_LENGTH, -0.1f, MAP_LENGTH)
        * Transform3D::Scale(MAP_LENGTH * 2.f, 0.1f, MAP_LENGTH * 2.f);

}


void Game::InitDrone()
{
    Mesh* meshArm1 = new Mesh("DroneArm1");
    meshArm1->LoadMesh(PATH_JOIN(window->props.selfDir, RESOURCE_PATH::MODELS, "primitives"), "box.obj");
    meshes[meshArm1->GetMeshID()] = meshArm1;

    Mesh* meshArm2 = new Mesh("DroneArm2");
    meshArm2->LoadMesh(PATH_JOIN(window->props.selfDir, RESOURCE_PATH::MODELS, "primitives"), "box.obj");
    meshes[meshArm2->GetMeshID()] = meshArm2;

    Mesh* meshLeg1 = new Mesh("DroneLeg1");
    meshLeg1->LoadMesh(PATH_JOIN(window->props.selfDir, RESOURCE_PATH::MODELS, "primitives"), "box.obj");
    meshes[meshLeg1->GetMeshID()] = meshLeg1;

    Mesh* meshLeg2 = new Mesh("DroneLeg2");
    meshLeg2->LoadMesh(PATH_JOIN(window->props.selfDir, RESOURCE_PATH::MODELS, "primitives"), "box.obj");
    meshes[meshLeg2->GetMeshID()] = meshLeg2;

    Mesh* meshLeg3 = new Mesh("DroneLeg3");
    meshLeg3->LoadMesh(PATH_JOIN(window->props.selfDir, RESOURCE_PATH::MODELS, "primitives"), "box.obj");
    meshes[meshLeg3->GetMeshID()] = meshLeg3;

    Mesh* meshLeg4 = new Mesh("DroneLeg4");
    meshLeg4->LoadMesh(PATH_JOIN(window->props.selfDir, RESOURCE_PATH::MODELS, "primitives"), "box.obj");
    meshes[meshLeg4->GetMeshID()] = meshLeg4;

    Mesh* meshPropeller1 = new Mesh("DronePropeller1");
    meshPropeller1->LoadMesh(PATH_JOIN(window->props.selfDir, RESOURCE_PATH::MODELS, "primitives"), "box.obj");
    meshes[meshPropeller1->GetMeshID()] = meshPropeller1;

    Mesh* meshPropeller2 = new Mesh("DronePropeller2");
    meshPropeller2->LoadMesh(PATH_JOIN(window->props.selfDir, RESOURCE_PATH::MODELS, "primitives"), "box.obj");
    meshes[meshPropeller2->GetMeshID()] = meshPropeller2;

    Mesh* meshPropeller3 = new Mesh("DronePropeller3");
    meshPropeller3->LoadMesh(PATH_JOIN(window->props.selfDir, RESOURCE_PATH::MODELS, "primitives"), "box.obj");
    meshes[meshPropeller3->GetMeshID()] = meshPropeller3;

    Mesh* meshPropeller4 = new Mesh("DronePropeller4");
    meshPropeller4->LoadMesh(PATH_JOIN(window->props.selfDir, RESOURCE_PATH::MODELS, "primitives"), "box.obj");
    meshes[meshPropeller4->GetMeshID()] = meshPropeller4;
}



void Game::InitForest()
{
    int idxTree = 0;
    InitTrees(rand() % 5 + 15, idxTree, 2);
    InitTrees(rand() % 5 + 10, idxTree, 3);
    InitTrees(rand() % 5 + 5, idxTree, 4);
}


void Game::InitDomes()
{
    int numDomes = 2;

    for (int i = 0; i < numDomes; i++) {
        string name = "";
        
        name = "Dome" + to_string(i) + "-Cube";
        Mesh* cubeMesh = new Mesh(name);
        cubeMesh->LoadMesh(PATH_JOIN(window->props.selfDir, RESOURCE_PATH::MODELS, "primitives"), "box.obj");
        meshes[cubeMesh->GetMeshID()] = cubeMesh;
        
        name = "Dome" + to_string(i) + "-SemiSphere";
        Mesh* semiSphereMesh = new Mesh(name);
        semiSphereMesh->LoadMesh(PATH_JOIN(window->props.selfDir, RESOURCE_PATH::MODELS, "primitives"), "sphere.obj");
        meshes[semiSphereMesh->GetMeshID()] = semiSphereMesh;

        float length = 5.f;
        float angleOY = static_cast<float>(std::rand()) / (static_cast<float>(RAND_MAX) / 360.f);
        glm::vec3 position = FindNewDomeCoordinate(length);
        this->domes.push_back(Dome(position, length, angleOY, cubeMesh, semiSphereMesh));
    }
}





void Game::InitTrees(int numTrees, int& idxTree, int numCones)
{
    for (int i = 0; i < numTrees; i++) {
        // Create a mesh for the cylinder

        idxTree++;
        string trunkName = "Tree" + to_string(idxTree) + "-Trunk";
        Mesh* trunkMesh = Object3D::CreateCylinder(trunkName);
        meshes[trunkMesh->GetMeshID()] = trunkMesh;
        float trunkHeight = 0.25f + static_cast<float>(std::rand()) / (static_cast<float>(RAND_MAX) / (1.5f - 0.25f));
        float trunkRadius = 0.2f + static_cast<float>(std::rand()) / (static_cast<float>(RAND_MAX) / (1.0f - 0.2f));
        Tree::Trunk trunk(trunkHeight, trunkRadius, trunkMesh);

        vector<Tree::Cone> cones;

        float coneHeight = 1.0f + static_cast<float>(std::rand()) / (static_cast<float>(RAND_MAX) / (1.75f - 1.0f));
        float coneRadius = 1.75f + static_cast<float>(std::rand()) / (static_cast<float>(RAND_MAX) / (2.25f - 1.75f));


        for (int j = 0; j < numCones; j++) {
            string coneName = trunkName + "-Cone" + to_string(j);
            Mesh* coneMesh = Object3D::CreateCone(coneName);
            meshes[coneMesh->GetMeshID()] = coneMesh;

            cones.push_back(Tree::Cone(coneHeight, coneRadius, coneMesh));
        }


        glm::vec3 position = FindNewTreeCoordinate(coneRadius);
        this->trees.push_back(Tree(position, trunk, cones)); // error here
    }
}


glm::vec3 Game::FindNewTreeCoordinate(float coneRadius)
{
    glm::vec3 position;

    do {
        position = GenerateRandomCoordinate();
    } while (!IsValidTreeCoordinate(position, coneRadius));
    
    return position;

}



glm::vec3 Game::FindNewDomeCoordinate(float length)
{
    glm::vec3 position;

    do {
        position = GenerateRandomCoordinate();
    } while (!IsValidDomeCoordinate(position, length));


    return position;
}






bool Game::IsValidTreeCoordinate(glm::vec3& position, float coneRadius)
{
    if ((position.x >= -2.5f && position.x <= 2.5f) && (position.z >= -2.5f && position.z <= 2.25f)) {
        return false;
    }

    return IsValidObstacleCoordinate(position, coneRadius);
}

bool Game::IsValidDomeCoordinate(glm::vec3& position, float length)
{
    if ((position.x >= -10.f && position.x <= 10.f) && (position.z >= -10.f && position.z <= 10.f)) {
        return false;
    }


    // Cercul circumscris patratului
    return (IsValidObstacleCoordinate(position, length * sqrt(2.0) / 2.0f));
}


bool Game::IsValidObstacleCoordinate(glm::vec3& position, float radius)
{
    for (Tree& tree : this->trees) {
        float distance = glm::length(position - tree.position);

        if (distance < (radius + tree.cones[0].radius)) {
            return false;
        }
    }

    for (Dome& dome : this->domes) {
        float distance = glm::length(position - dome.position);

        if (distance < (radius + dome.length * sqrt(2.f) / 2.f)) {
            return false;
        }
    }

    return true;
}


glm::vec3 Game::GenerateRandomCoordinate()
{
    float x = (float)(rand() % (int)(MAP_LENGTH - 5.f)) - (MAP_LENGTH - 5.f) / 2.0;
    float z = (float)(rand() % (int)(MAP_LENGTH - 5.f)) - (MAP_LENGTH - 5.f) / 2.0;

    // Place the position on the xOz plane
    return glm::vec3(x, 0.f, z);
}


void Game::RenderColoredMesh(Mesh* mesh, const glm::vec3& color, const glm::mat4& modelMatrix)
{
    if (!mesh || !shaders["VertexColor"]->program) return;

    glUseProgram(shaders["VertexColor"]->program);

    GLint locObjectColor = glGetUniformLocation(shaders["VertexColor"]->program, "objectColor");
    glUniform3fv(locObjectColor, 1, glm::value_ptr(color));

    glUniformMatrix4fv(glGetUniformLocation(shaders["VertexColor"]->program, "model"), 1, GL_FALSE, glm::value_ptr(modelMatrix));
    glUniformMatrix4fv(glGetUniformLocation(shaders["VertexColor"]->program, "view"), 1, GL_FALSE, glm::value_ptr(camera->GetViewMatrix()));
    glUniformMatrix4fv(glGetUniformLocation(shaders["VertexColor"]->program, "projection"), 1, GL_FALSE, glm::value_ptr(projectionMatrix));

    mesh->Render();
}




void Game::FrameStart()
{
    // Clears the color buffer (using the previously set color) and depth buffer
    glClearColor(0, 0, 0, 1);
    glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
}



void Game::RenderDrone()
{
    RenderMesh(meshes["DroneArm1"], shaders["Simple"], drone.arm1.modelMatrix);
    RenderMesh(meshes["DroneArm2"], shaders["Simple"], drone.arm2.modelMatrix);
    
    RenderMesh(meshes["DroneLeg1"], shaders["Simple"], drone.leg1.modelMatrix);
    RenderMesh(meshes["DroneLeg2"], shaders["Simple"], drone.leg2.modelMatrix);
    RenderMesh(meshes["DroneLeg3"], shaders["Simple"], drone.leg3.modelMatrix);
    RenderMesh(meshes["DroneLeg4"], shaders["Simple"], drone.leg4.modelMatrix);

    RenderMesh(meshes["DronePropeller1"], shaders["Simple"], drone.propeller1.modelMatrix);
    RenderMesh(meshes["DronePropeller2"], shaders["Simple"], drone.propeller2.modelMatrix);
    RenderMesh(meshes["DronePropeller3"], shaders["Simple"], drone.propeller3.modelMatrix);
    RenderMesh(meshes["DronePropeller4"], shaders["Simple"], drone.propeller4.modelMatrix);

    RenderColoredMesh(meshes["DroneArm1"], COLOR_GREY, drone.arm1.modelMatrix);
    RenderColoredMesh(meshes["DroneArm2"], COLOR_GREY, drone.arm2.modelMatrix);

    RenderColoredMesh(meshes["DroneLeg1"], COLOR_GREY, drone.leg1.modelMatrix);
    RenderColoredMesh(meshes["DroneLeg2"], COLOR_GREY, drone.leg2.modelMatrix);
    RenderColoredMesh(meshes["DroneLeg3"], COLOR_GREY, drone.leg3.modelMatrix);
    RenderColoredMesh(meshes["DroneLeg4"], COLOR_GREY, drone.leg4.modelMatrix);

    RenderColoredMesh(meshes["DronePropeller1"], COLOR_BLACK, drone.propeller1.modelMatrix);
    RenderColoredMesh(meshes["DronePropeller2"], COLOR_BLACK, drone.propeller2.modelMatrix);
    RenderColoredMesh(meshes["DronePropeller3"], COLOR_BLACK, drone.propeller3.modelMatrix);
    RenderColoredMesh(meshes["DronePropeller4"], COLOR_BLACK, drone.propeller4.modelMatrix);

}


void Game::RenderScene()
{
    RenderMesh(meshes["Terrain"], shaders["Simple"], terrainModelMatrix);


    for (Tree& tree : trees) {
        RenderMesh(tree.trunk.mesh, shaders["Simple"], tree.trunk.modelMatrix);
        RenderColoredMesh(tree.trunk.mesh, COLOR_BROWN_TREE_TRUNK, tree.trunk.modelMatrix);
        for (Tree::Cone& cone : tree.cones) {
            RenderMesh(cone.mesh, shaders["Simple"], cone.modelMatrix);
            RenderColoredMesh(cone.mesh, COLOR_GREEN_TREE_CONE, cone.modelMatrix);
        }
    }

    for (Dome& dome : domes) {
        RenderMesh(dome.cubeMesh, shaders["Simple"], dome.cubeModelMatrix);
        RenderMesh(dome.semiSphereMesh, shaders["Simple"], dome.semiSphereModelMatrix);
    }

    RenderDrone();
    DrawCoordinateSystem();
}


void Game::UpdateScene(float deltaTimeSeconds)
{
    drone.Update(deltaTimeSeconds);

    glm::ivec2 resolution = window->GetResolution();
    glViewport(0, 0, resolution.x, resolution.y);

}

void Game::Update(float deltaTimeSeconds)
{
    // Clear depth buffer and set polygon mode
    glLineWidth(3);
    glPointSize(5);
    glPolygonMode(GL_FRONT_AND_BACK, polygonMode);

    UpdateScene(deltaTimeSeconds);

    RenderScene();

    glClear(GL_DEPTH_BUFFER_BIT);
    glViewport(miniViewportArea.x, miniViewportArea.y, miniViewportArea.width, miniViewportArea.height);

    RenderScene();
}

void Game::FrameEnd()
{
}


/*
 *  These are callback functions. To find more about callbacks and
 *  how they behave, see `input_controller.h`.
 */


void Game::OnInputUpdate(float deltaTime, int mods)
{
    /*
    if ((mods & GLFW_MOD_CONTROL) && window->KeyHold(GLFW_KEY_1)) {
        if (window->KeyHold(GLFW_KEY_2) || window->KeyHold(GLFW_KEY_3) || window->KeyHold(GLFW_KEY_4)) {
            return;
        }

        camera->cameraMode = CameraMode::FirstPerson_SimultaneousRotation;
    }

    if ((mods & GLFW_MOD_CONTROL) && window->KeyHold(GLFW_KEY_2)) {
        if (window->KeyHold(GLFW_KEY_1) || window->KeyHold(GLFW_KEY_3) || window->KeyHold(GLFW_KEY_4)) {
            return;
        }

        camera->cameraMode = CameraMode::FirstPerson_No_SimultaneousRotation;
    }

    if ((mods & GLFW_MOD_CONTROL) && window->KeyHold(GLFW_KEY_3)) {
        if (window->KeyHold(GLFW_KEY_1) || window->KeyHold(GLFW_KEY_2) || window->KeyHold(GLFW_KEY_4)) {
            return;
        }

        camera->cameraMode = CameraMode::ThirdPerson_SimultaneousRotation;
    }

    if ((mods & GLFW_MOD_CONTROL) && window->KeyHold(GLFW_KEY_4)) {
        if (window->KeyHold(GLFW_KEY_1) || window->KeyHold(GLFW_KEY_2) || window->KeyHold(GLFW_KEY_3)) {
            return;
        }
     
        camera->cameraMode = CameraMode::ThirdPerson_No_SimultaneousRotation;
    }
    */


    if (window->KeyHold(GLFW_KEY_A))
    {
        if (!window->KeyHold(GLFW_KEY_D)) {
            drone.MoveLeft(deltaTime);
        }
    }
    if (window->KeyHold(GLFW_KEY_D))
    {
        if (!window->KeyHold(GLFW_KEY_A)) {
            drone.MoveRight(deltaTime);
        }
    }
    if (window->KeyHold(GLFW_KEY_W))
    {
        if (!window->KeyHold(GLFW_KEY_S)) {
            drone.MoveForward(deltaTime);
        }
    }
    if (window->KeyHold(GLFW_KEY_S))
    {

        if (!window->KeyHold(GLFW_KEY_W)) {
            drone.MoveBackward(deltaTime);
        }
    }
    if (window->KeyHold(GLFW_KEY_UP)) {
        if (!window->KeyHold(GLFW_KEY_DOWN)) {
            drone.AscendAltitude(deltaTime);
        }
    }
    if (window->KeyHold(GLFW_KEY_DOWN)) {
        if (!window->KeyHold(GLFW_KEY_UP)) {
            drone.DescendAltitude(deltaTime);
        }
    }
    if (window->KeyHold(GLFW_KEY_LEFT)) {
        if (!window->KeyHold(GLFW_KEY_RIGHT)) {
            drone.RotateLeft(deltaTime);
        }
    }
    if (window->KeyHold(GLFW_KEY_RIGHT)) {
        if (!window->KeyHold(GLFW_KEY_LEFT)) {
            drone.RotateRight(deltaTime);
        }
    }

    if (!(window->KeyHold(GLFW_KEY_A) || window->KeyHold(GLFW_KEY_D)
        || window->KeyHold(GLFW_KEY_W) || window->KeyHold(GLFW_KEY_S))) {
        drone.AnulateFlightSpeed();
    }

    if (!window->KeyHold(GLFW_KEY_UP) && !window->KeyHold(GLFW_KEY_DOWN)) {
        drone.AnulateAltitudeAscendSpeed();
        drone.AnulateAltitudeDescendSpeed();
    }
}


void Game::OnKeyPress(int key, int mods)
{
    // TODO(student): Add viewport movement and scaling logic
    if (key == GLFW_KEY_I)
    {
        miniViewportArea.y += 10;
    }
    if (key == GLFW_KEY_K)
    {
        miniViewportArea.y -= 10;
    }
    if (key == GLFW_KEY_J)
    {
        miniViewportArea.x -= 10;
    }
    if (key == GLFW_KEY_L)
    {
        miniViewportArea.x += 10;
    }
    if (key == GLFW_KEY_U)
    {
        miniViewportArea.width -= 10;
        const float aspectRatio = 16.0f / 9.0f;
        miniViewportArea.height = static_cast<int>(miniViewportArea.width / aspectRatio);
    }
    if (key == GLFW_KEY_O)
    {
        miniViewportArea.width += 10;
        const float aspectRatio = 16.0f / 9.0f;
        miniViewportArea.height = static_cast<int>(miniViewportArea.width / aspectRatio);
    }
}


void Game::OnKeyRelease(int key, int mods)
{
    // Add key release event
}


void Game::OnMouseMove(int mouseX, int mouseY, int deltaX, int deltaY)
{
    // Add mouse move event
}


void Game::OnMouseBtnPress(int mouseX, int mouseY, int button, int mods)
{
    // Add mouse button press event
}


void Game::OnMouseBtnRelease(int mouseX, int mouseY, int button, int mods)
{
    // Add mouse button release event
}


void Game::OnMouseScroll(int mouseX, int mouseY, int offsetX, int offsetY)
{
}


void Game::OnWindowResize(int width, int height)
{
}
